# ESP32-DEVKITV1
ESP32-DEVKITV1 EAGLE-FOOTPRINT

![ESP32](https://user-images.githubusercontent.com/28555587/72717720-9b04b200-3b9a-11ea-99bd-5852cf951d55.png)

![ESP32s](https://user-images.githubusercontent.com/28555587/72717813-c2f41580-3b9a-11ea-9db8-c8ffdac5e7d9.png)
