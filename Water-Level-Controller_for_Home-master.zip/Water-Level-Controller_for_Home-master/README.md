# DIY_WaterLevel_For_Home
Simple Water Level Controller Using Arduino
Water Level
Automatic detects Water level of Tank and turn on and off motor according to it
https://shridatt.github.io
modified 27 Oct 2019 Diwali
by Shridatt Dudhat
           _            _
           |         G  |  => H
           |            |
           |            |
           |         R  |  => L
           |            |
           |            |
           \_________B__/  => GND
This code is in the public domain.
http://shridattdudhat.github.io

![image](https://user-images.githubusercontent.com/28555587/93738080-8170aa00-fc02-11ea-819e-62bad9f96655.png)

![photo_2020-11-19_15-15-10](https://user-images.githubusercontent.com/28555587/99650918-000b8b80-2a7c-11eb-9244-f32bd02ca8ac.jpg)

![image](https://user-images.githubusercontent.com/28555587/95045279-3a54df80-06ff-11eb-917c-44fdb864584e.png)

![image](https://user-images.githubusercontent.com/28555587/94338630-7f975400-0011-11eb-9be5-5a77aab3c060.png)

